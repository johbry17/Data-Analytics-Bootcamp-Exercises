# MapReduce Use Cases

In this activity, you’ll find common use cases for MapReduce. The ability to research and learn about common use cases is an important skill to have in your career.

## Instructions

Using a search engine, search for two or three use cases of MapReduce. Be prepared to share your findings with the class. 

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.