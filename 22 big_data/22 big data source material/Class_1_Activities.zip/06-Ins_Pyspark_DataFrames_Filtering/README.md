# Instructor Demo

## References

Google Research Datasets repository (2021). Data modified from "Nutrition5k Dataset". Retrieved from GitHub [https://github.com/google-research-datasets/Nutrition5k]


---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
