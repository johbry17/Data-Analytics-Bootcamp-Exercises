# Everyone Do

In this activity you'll code along with the instructor to implement MapReduce using MRJob.

## References

National Centers for Environmental Information: National Oceanic and Atmospheric Administration. Daily Summaries Station Details. Austin 14.7 WSW, TX  US. Retrieved from [https://www.ncdc.noaa.gov/cdo-web/datasets/GHCND/stations/GHCND:US1TXHYS059/detail](https://www.ncdc.noaa.gov/cdo-web/datasets/GHCND/stations/GHCND:US1TXHYS059/detail).

---

Copyright 2022 2U. All Rights Reserved.
