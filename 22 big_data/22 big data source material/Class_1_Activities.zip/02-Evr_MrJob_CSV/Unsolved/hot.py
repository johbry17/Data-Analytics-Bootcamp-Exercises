"""
Find the number of hot days in Austin for 2017
"""
from mrjob.job import MRJob

# Create a class, `Hot_Days`, which inherits the `MrJob` class.
class Hot_Days(MRJob):
    # Define a mapper function
    def mapper(self, key, line):

        # Use the `mapper` function to split each line in the CSV file on the comma

        # Write a conditional statement to find the days over 100 degrees.


    # Use the `reducer` function to aggregate the total number of hot days.
    def reducer(self, name, hot):


if __name__ == "__main__":
    Hot_Days.run()
