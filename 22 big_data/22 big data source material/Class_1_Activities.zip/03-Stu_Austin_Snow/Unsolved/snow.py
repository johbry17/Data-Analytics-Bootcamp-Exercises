"""
How many stations recorded snow per date?
"""
from mrjob.job import MRJob

# Create a class, `Snow_days`, which inherits the `MrJob` class.
class :

    # Define a mapper function
    def mapper(self, key, line):

        # Use the `mapper` function to split each line in the CSV file on the comma

        # Write a conditional statement to find the days it snowed.

    # Use the `reducer` function to aggregate the total number of stations recording snow per date.
    def reducer(self, date, snow):



if __name__ == "__main__":
    Snow_days.run()
